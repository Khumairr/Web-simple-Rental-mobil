<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- link fontawesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <link rel="stylesheet" href="stylee.css">
    <title>Gallery Grid By Nam School Admin</title>
</head>
<body>
    
    <div class="page">
    <!-- Ini Judul -->
    <h1>My Gallery</h1>
 
    <!-- Ini Gallery -->
    <div class="gallery_container_parent">
        <div class="gallery_container">
            <figure class="gallery_item item_1" onclick="openmodal();currentslide(1)">
                <img src="gambar/1.jpg" alt="1">
                <figcaption class="caption">My Lovely car <br><br> Tap To Zoom In <br> <i class="fas fa-search"></i> </figcaption>
            </figure>
     
            <figure class="gallery_item item_2" onclick="openmodal();currentslide(2)">
                <img src="gambar/2.jpg" alt="2">
                <figcaption class="caption">My Lovely car <br><br> Tap To Zoom In <br> <i class="fas fa-search"></i> </figcaption>
            </figure>
     
            <figure class="gallery_item item_3" onclick="openmodal();currentslide(3)">
                <img src="gambar/3.jpg" alt="3">
                <figcaption class="caption">My Lovely Car <br><br> Tap To Zoom In <br> <i class="fas fa-search"></i> </figcaption>
            </figure>
     
            <figure class="gallery_item item_4" onclick="openmodal();currentslide(4)">
                <img src="gambar/4.jpeg" alt="4">
                <figcaption class="caption">My Lovely car <br><br> Tap To Zoom In <br> <i class="fas fa-search"></i> </figcaption>
            </figure>
     
            <figure class="gallery_item item_5" onclick="openmodal();currentslide(5)">
                <img src="gambar/5.jpg" alt="5">
                <figcaption class="caption">My Lovely car <br><br> Tap To Zoom In <br> <i class="fas fa-search"></i> </figcaption>
            </figure>
     
            <figure class="gallery_item item_6" onclick="openmodal();currentslide(6)">
                <img src="gambar/6.jpg" alt="6">
                <figcaption class="caption">My Lovely car <br><br> Tap To Zoom In <br> <i class="fas fa-search"></i> </figcaption>
            </figure>
     
            <figure class="gallery_item item_7" onclick="openmodal();currentslide(7)">
                <img src="gambar/7.webp" alt="7">
                <figcaption class="caption">My Lovely car <br><br> Tap To Zoom In <br> <i class="fas fa-search"></i> </figcaption>
            </figure>
        </div>
    </div>
     
    <!-- Ini Lightbox  -->
    <div class="lightbox_container">
        <i class="fas fa-times" id="close"></i>
        <div class="parent_navigation">
            <span class="prev" id="ripple">&#10094;</span>
            <span class="next" id="ripple">&#10095;</span>
        </div>
 
        <figure class="lightbox_item">
            <img src="gambar/1.jpg" alt="1">
            <figcaption class="caption_lightbox">Ini Gambar Mobil</figcaption>
        </figure>
 
        <figure class="lightbox_item">
            <img src="gambar/2.jpg" alt="2">
            <figcaption class="caption_lightbox">Ini Gambar Mobil</figcaption>
        </figure>
 
        <figure class="lightbox_item">
            <img src="gambar/3.jpg" alt="3">
            <figcaption class="caption_lightbox">Ini Gambar Mobil</figcaption>
        </figure>
 
        <figure class="lightbox_item">
            <img src="gambar/4.jpeg" alt="4">
            <figcaption class="caption_lightbox">Ini Gambar Mobil</figcaption>
        </figure>
 
        <figure class="lightbox_item">
             <img src="gambar/5.jpg" alt="5">
            <figcaption class="caption_lightbox">Ini Gambar Mobil</figcaption>
        </figure>
 
        <figure class="lightbox_item">
            <img src="gambar/6.jpg" alt="6">
            <figcaption class="caption_lightbox">Ini Gambar Mobil</figcaption>
        </figure>
 
        <figure class="lightbox_item">
            <img src="gambar/7.webp" alt="7">
            <figcaption class="caption_lightbox">Ini Gambar Mobil</figcaption>
        </figure>
    </div>
    </div>
    <!-- script javascript -->
    <script src="script.js"></script>
    
</body>
</html>