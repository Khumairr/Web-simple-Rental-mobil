<!DOCTYPE html>
<html lang="en">
<head>
    <title>PESANAN</title>
</head>
<body>
<br>
<br>
<br>
<br>
<?php
  $nama = $_POST['namcus'];
  $tgl = $_POST['tanggal'];
  $durasi = $_POST['durasi'];
  $pilih = $_POST['tipe'];
    if ("fortuner")
    {
        $harga = "250000";
        $total = $harga*$durasi;
    }
    elseif ("pajero")
    {
        $harga = "200000";
        $total = $harga*$durasi;
    }
    elseif ("civic")
    {
        $harga = "300000";
        $total = $harga*$durasi;
    }
    elseif ("inova")
    {
        $harga = "175000";
        $total = $harga*$durasi;
    }
    elseif ("bmw")
    {
        $harga = "400000";
        $total = $harga*$durasi;
    }
    elseif ("crv")
    {
        $harga = "180000";
        $total = $harga*$durasi;
    }
    elseif ("alphard")
    {
        $harga = "450000";
        $total = $harga*$durasi;
    }
    elseif ("mercy")
    {
        $harga = "500000";
        $total = $harga*$durasi;
    }
    else
    {
        salah;
    }
?>
<div class="page" align="center">
    <table border="1" class="table">
    <thead>
      <tr>
        <th scope="col">No</th>
        <th scope="col">Nama Customer</th>
        <th scope="col">Tanggal</th>
        <th scope="col">Merk Mobil</th>
        <th scope="col">Lama Pinjam</th>
        <th scope="col">Total Harga</th>
      </tr>
    </thead>
    <tbody>
      <tr>
      <th scope="row">1</th>    
        <td><?php echo $nama ?></td>
        <td><?php echo $tgl ?></td>
        <td><?php echo $pilih ?></td>
        <td><?php echo $durasi ?></td>
        <td><?php echo $total ?></td>
      </tr>
    </tbody>
    </table>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

</body>
</html>