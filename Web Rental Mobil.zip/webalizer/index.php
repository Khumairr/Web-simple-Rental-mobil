<!DOCTYPE html>
<html lang="en">
<head>
    <title>Membuat Website dengan PHP | Niagahoster</title>
    <meta charset="UTF-8">
    <meta name="description" content="Niagahoster">
    <link rel="stylesheet" href="style.css" type="text/css">
</head>
<body>
    <header class="coba">
        <div class="wrapper">
            <nav id="navigation">
                <div class="logo"><a href="">RENTAL MOBIL</a></div>
                <div class="menu">
                    <ul>
                        <li><a href="index.php?page=home">Home</a></li>
                        <li><a href="index.php?page=Listmobil">List Mobil</a></li>
                        <li><a href="index.php?page=pesanan">Pesanan</a></li>
                        <li><a href="index.php?page=galeri">Galeri</a></li>
                        <li><a href="index.php?page=contact">Contact</a></li>
                        <li><a href="login.php" page="logout">Logout</a></li>
                    </ul>
                </div>
            </nav>
        </div>
    </header>
    <div id="contents">
        <?php 
        if(isset($_GET['page'])){
            $page = $_GET['page'];
 
            switch ($page) {
                case 'home':
                    include "home.php";
                    break;
                case 'Listmobil':
                    include "Listmobil.php";
                    break;
                case 'pesanan':
                    include "pesanan.php";
                    break;
                case 'galeri':
                    include "indexx.php";
                    break;
                case 'contact':
                    include "contact.php";
                    break;          
            }
        } else {
            include "home.php";
        }
        ?>
    </div>
    <hr class="new4">
    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-6">
                    <h4>About</h4>
                    <p class="text-justify">Rentedcar.com <i>Rental Mobil </i> as a Layanan Rental Mobil Jakarta. Semua orang, termasuk Anda, berhak untuk menikmati layanan transportasi yang aman dan nyaman, termasuk untuk keperluan perjalanan jangka pendek. Kami menyediakan layanan sewa kendaraan harian untuk semua aktivitas Anda.</p>
                </div>
            </div>
            <hr>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-6 col-xs-12">
                    <p class="copyright-text">Copyright &copy; 2017 All Rights Reserved by 
                        <a href="#">Scanfcode</a>.
                    </p>
                </div>
                <div class="col-md-6 d-flex justify-content-end">
                    <div class="icon-contact">
                        <label class="font-weight-bold">Follow Us </label>
                        <a href="#"><img src="img/fb.png" class="mr-3 ml-4" data-toggle="tooltip" title="Facebook"></a>
                        <a href="#"><img src="img/ig.png" class="mr-3" data-toggle="tooltip" title="Instagram"></a>
                        <a href="#"><img src="img/twitter.png" class="" data-toggle="tooltip" title="Twitter"></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>
