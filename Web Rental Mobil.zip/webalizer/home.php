<!DOCTYPE html>
<html lang="en">
<head>
    <style>
.jumbotron {
background-image: url(contoh.jpg);
background-size: cover;
height: 750px;
width: 100%;
color: white;
}
form {
    width:1050px;
    margin:50px auto;
}
.search {
    float: center;
    padding:9px 400px;
    background:white;
    border:0px solid #dbdbdb;
}
.button {
    float: center;
    position:relative;
    padding:6px 15px;
    left:-2px;
    border:2px solid #53bd84;
    background-color:#53bd84;
    color:#fafafa;
}
.button:hover  {
    background-color:#fafafa;
    color:#207cca;
}
hr.new4 {
  border: 1px solid red;
}
.malasngoding-slider { 
	border: 10px solid #efefef; 
	position: relative; 
	overflow: hidden; 
	background: #efefef;
}
 
.malasngoding-slider { 
	margin:20px auto;
	width: 768px;
	height: 450px; 
}
 
.isi-slider img { 
	width: 768px;
	height: 450px; 
	float: left;
}
 
.isi-slider { 
	position: absolute; 
	width:3900px;  
 
	/*pengaturan durasi lama tampil gambar bisa di atur di bawah ini*/
	animation-name:slider;
	animation-duration:16s;
	animation-timing-function: ease-in-out;
	animation-iteration-count:infinite;
	-webkit-animation-name:slider;
	-webkit-animation-duration:12s;
	-webkit-animation-timing-function: ease-in-out;
	-webkit-animation-iteration-count:infinite;
	-moz-animation-name:slider;
	-moz-animation-duration:16s;
	-moz-animation-timing-function: ease-in-out;
	-moz-animation-iteration-count:infinite;
	-o-animation-name:slider;
	-o-animation-duration:16s;
	-o-animation-timing-function: ease-in-out;
	-o-animation-iteration-count:infinite;
}
 
 
/*saat gambar di hover oleh cursor mouse maka berhenti slide*/
.isi-slider:hover { 
	-webkit-animation-play-state:paused; 
	-moz-animation-play-state:paused; 
	-o-animation-play-state:paused; 
	animation-play-state:paused; }
}
 
.isi-slider img { 
	float: right; 
}
 
.malasngoding-slider:after { 
	font-size: 150px; 
	position: absolute; 
	z-index: 12; 
	color: rgba(255,255,255, 0); 
	left: 300px; top: 80px; 
	-webkit-transition: 1s all ease-in-out; 
	-moz-transition: 1s all ease-in-out; 
	transition: 1s all ease-in-out; 
}
 
.malasngoding-slider:hover:after { 
	color: rgba(255,255,255, 0.6);  
}
 
 
 
@-moz-keyframes slider {     
	0% {
		left: 0; opacity: 0; 
	}     
	2% {
		opacity: 1; 
	}     
	20% {
		left: 0; opacity: 1; 
	}     
	21% {
		opacity: 0; 
	}     
	24% {
		opacity: 0; 
	}     
	25% {
		left: -768px; opacity: 1; 
	}       
	45% {
		left: -768px; opacity: 1; 
	}     
	46% {
		opacity: 0; 
	}     
	48% {
		opacity: 0; 
	}     
	50% {
		left: -1536px; opacity: 1; 
	}     
	70% {
		left: -1536px; opacity: 1; 
	}     
	72% {
		opacity: 0; 
	}     
	74% {
		opacity: 0; 
	}    
	75% {
		left: -2304px; opacity: 1; 
	}   	
	95% {
		left: -2304px; opacity: 1; 
	}   	
	97% { 
		left: -2304px; opacity: 0;
	}   	
	100% {
		left: 0; opacity: 0; 
	}
} 
 
@-webkit-keyframes slider {     
	0% {
		left: 0; opacity: 0; 
	}     
	2% {
		opacity: 1; 
	}     
	20% {
		left: 0; opacity: 1; 
	}     
	21% {
		opacity: 0; 
	}     
	24% {
		opacity: 0; 
	}     
	25% {
		left: -768px; opacity: 1; 
	}       
	45% {
		left: -768px; opacity: 1; 
	}     
	46% {
		opacity: 0; 
	}     
	48% {
		opacity: 0; 
	}     
	50% {
		left: -1536px; opacity: 1; 
	}     
	70% {
		left: -1536px; opacity: 1; 
	}     
	72% {
		opacity: 0; 
	}     
	74% {
		opacity: 0; 
	}    
	75% {
		left: -2304px; opacity: 1; 
	}   	
	95% {
		left: -2304px; opacity: 1; 
	}   	
	97% { 
		left: -2304px; opacity: 0;
	}   	
	100% {
		left: 0; opacity: 0; 
	}
} 
 
 
@keyframes slider {     
	0% {
		left: 0; opacity: 0; 
	}     
	2% {
		opacity: 1; 
	}     
	20% {
		left: 0; opacity: 1; 
	}     
	21% {
		opacity: 0; 
	}     
	24% {
		opacity: 0; 
	}     
	25% {
		left: -768px; opacity: 1; 
	}     
	45% {
		left: -768px; opacity: 1; 
	}     
	46% {
		opacity: 0; 
	}     
	48% {
		opacity: 0; 
	}     
	50% {
		left: -1536px; opacity: 1; 
	}     
	70% {
		left: -1536px; opacity: 1; 
	}     
	72% {
		opacity: 0; 
	}     
	74% {
		opacity: 0; 
	}    
	75% {
		left: -2304px; opacity: 1; 
	}   	
	95% {
		left: -2304px; opacity: 1; 
	}   	
	97% { 
		left: -2304px; opacity: 0; 
	} 
 
	100% {
		left: 0; opacity: 0; 
	}
}
.step {
  position: relative; }
  .step .number {
    font-weight: 900; }
  .step > span {
    font-size: 100px;
    color: #0779e4;
    font-weight: 900;
    top: 0;
    left: -30px;
    position: absolute; }
  .step .step-inner {
    position: relative;
    padding: 40px;
    -webkit-box-shadow: 0 15px 30px 0 rgba(0, 0, 0, 0.1);
    box-shadow: 0 15px 30px 0 rgba(0, 0, 0, 0.1);
    background: #fff;
    font-size: 14px; }
    .step .step-inner h3 {
      font-size: 20px;
      color: #000;
      font-weight: 700; }
    .step .step-inner *:last-child {
      margin-bottom: 0; }
    .step .step-inner p {
      color: #999; }

    </style>
    <title>Home</title>
</head>
<body>
<div class="page">
<div class="jumbotron jumbotron-fluid">
    <div class="container">
    </div>
</div>
<hr class="new4">
<form>
  <input class="search" type="text" placeholder="Search" required>	
  <input class="button" type="button" value="Cari">		
</form>


<div class=malasngoding-slider>
  <div class=isi-slider>
  <img src="mustang.jpg" alt="Gambar1" style="display:block; margin:auto;">
  <img src="mustang2.jpg" alt="Gambar2" style="display:block; margin:auto;">
  <img src="mustang3.jpg" alt="Gambar3" style="display:block; margin:auto;">
  </div>
  </div>
  <figure class="text-center" align="center">
  <blockquote class="blockquote">
    <h1>SELAMAT DATANG</h1>
  </blockquote>
  <figcaption class="blockquote-footer">
  Bagaimana Cara Mememasan? Mudah Untuk Dilakukan <cite title="Source Title"></cite>
  </figcaption>
</figure>
<br>
<hr class="new4">
<div class="site-section">
          <div class="row mb-5">
            <div class="col-lg-4 mb-4 mb-lg-0">
              <div class="step">
                <span>1</span>
                <div class="step-inner">
                  <span class="number text-primary">01.</span>
                  <h3>Pilih Mobil</h3>
                  <p>Kunjungi Menu Pada List Mobil</p>
                </div>
              </div>
            </div>
			<hr class="new4">
            <div class="col-lg-4 mb-4 mb-lg-0">
              <div class="step">
                <span>2</span>
                <div class="step-inner">
                  <span class="number text-primary">02.</span>
                  <h3>Isi Formnya</h3>
                  <p>Lengkapi Isi Form Pada Menu List Mobil</p>
                </div>
              </div>
            </div>
			<hr class="new4">
            <div class="col-lg-4 mb-4 mb-lg-0">
              <div class="step">
                <span>3</span>
                <div class="step-inner">
                  <span class="number text-primary">03.</span>
                  <h3>Pembayaran</h3>
                  <p>Total harga akan ditampilkan di Menu Pesanan</p>
                </div>
				<hr class="new4">
              </div>
            </div>
    
</div>
</body>
</html>