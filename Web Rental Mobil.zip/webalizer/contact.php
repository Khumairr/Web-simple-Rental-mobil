<!DOCTYPE html>
<html lang="en">
<head>
    <title>Contact</title>
    <style>
input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.container {
  border-radius: 5px;
  padding: 20px;
}
hr.new5 {
  border: 10px solid green;
  border-radius: 5px;
}
    </style>
</head>
<body>
<div class="page">
    <br>
    <br>
    <br>
    <br>
    <br>
    <h2 align="center">Hubungi Kami</h2>
    <div class="container">
  <form action="action_page.php">

    <label for="fname">First Name</label>
    <input type="text" id="fname" name="firstname" placeholder="Your name..">

    <label for="lname">Last Name</label>
    <input type="text" id="lname" name="lastname" placeholder="Your last name..">

    <label for="country">Country</label>
    <select id="country" name="country">
      <option value="australia">INDONESIA</option>
      <option value="canada">CANADA</option>
      <option value="usa">USA</option>
      <option value="usa">PALESTINA</option>
      <option value="usa">INGGRIS</option>
    </select>

    <label for="subject">Description</label>
    <textarea id="subject" name="subject" placeholder="Write something.." style="height:200px"></textarea>

    <input type="submit" value="Submit">

  </form>
</div>
<hr class="new5">

    <br>
    <p>Telp: 0274-2885822
        <br>WA: 0895395186038
        <br>Senin - Minggu
    24 Jam Non Stop</p>
 <br>
    <p>Jl. Margonda Raya No.8, Pondok Cina, Kecamatan Beji, Kota Depok, Jawa Barat 16424</p><br>
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.1139431781594!2d106.82881081460822!3d-6
        .379290364174728!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69ec11e6ecbe35%3A0x45e4fdba5c9fa9c0!
        2sJl.%20Margonda%20Raya%2C%20Kota%20Depok%2C%20Jawa%20Barat!5e0!3m2!1sen!2sid!4v1669365428692!5m2!1sen!2si
        d" width="500" height="300" style="border:0;" 
        allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>"
    </div>
    <br>
</body>
</html>