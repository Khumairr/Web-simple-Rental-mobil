<!DOCTYPE html>
<html lang="en">
<head>
    <title>LOGIN</title>
    <script src="main.js"></script>
    <style>
  body {
  padding: 25px;
  background-color: white;
  color: black;
  font-size: 25px;
}

.dark-mode {
  background-color: black;
  color: white;
}	
form {
  border: 3px solid #f1f1f1;
}
h1 {
  font-size: 30px;
  text-align: center;
}

input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #04AA6D;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
}

button:hover {
  opacity: 0.8;
}
.imgcontainer {
width: 599px;
text-align: center;
margin: auto;
border: 21px solid gray;
padding: 5px;
}
img{
  width: 600px;
  height: 300px;
}
    </style>

</head>
<body>
<body>    
<h1>LOGIN FORM</h1>
<div class="imgcontainer">
  <img src="jenis-mobil-toyota.jpg">
  </div>
  <br>
    <?php
session_start();
$username = 'admin';
$password = '12345';
if (isset($_POST['submit'])) {
    if ($_POST['username'] == $username && $_POST['password'] == $password){
        //Membuat Session
        $_SESSION["username"] = $username; 
        echo "Anda Berhasil Login $username";
        header("Location: index.php");
    } else {
        // Tampilkan Pesan Error
        display_login_form();
        echo '<p>Username Atau Password Tidak Benar</p>';   
    }
}    
else { 
    display_login_form();
}
function display_login_form(){ ?>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method='post'>
    <label for="username"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="username" id="username">
    <label for="password"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" id="password">
    <button type="submit" name="submit" value="submit">Login</button>
    </form>    
<?php } ?>
<h4 align="center">Dark/Light Mode!</h4>
<button onclick="myFunction()">Change</button>
</body>
</html>