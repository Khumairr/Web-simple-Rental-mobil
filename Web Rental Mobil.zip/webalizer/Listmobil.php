<!DOCTYPE html>
<html lang="en">
<head>
    <title>list mobil</title>
</head>
<style>
input[type=text], select {
  width: 100%;
  padding: 12px 200px;
  margin: 8px 0;
  display: inline-block;
  border: 2px solid #ccc;
  border-radius: 0px;
  box-sizing: border-box;
}
input[type=number], select {
  width: 100%;
  padding: 12px 200px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 0px;
  box-sizing: border-box;
}
input[type=date], select {
  width: 100%;
  padding: 12px 200px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 0px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
input[type=reset] {
  width: 100%;
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
div {
  border-radius: 5px;
  padding: 2px;
}
</style>
<body>
<div class="page">
<div class="container">
              <div class="card" style="width: 19rem; float: right; margin: 40px;">
                  <img src="download.jpg"width="300" height="200" class="card-img-top" alt="Foutuner">
                  <div class="card-body">
                      <h5 class="card-title">FOUTUNER</h5>
                      <p class="card-text">Rp 250.000/day,-</p>
                      <a href="detail" class="btn btn-warning">Detail</a>
                  </div>
              </div>
<div class="card" style="width: 14rem; float: right; margin: 40px;">
    <img src="PAJERO.jpeg" width="280" height="200" class="card-img-top" alt="Pajero Sport">
    <div class="card-body">
        <h5 class="card-title">PAJERO SPORT</h5>
        <p class="card-text">Rp 200.000/day,-</p>
        <a href="#" class="btn btn-warning">Detail</a>
    </div>
</div>
<div class="card" style="width: 15rem; float: right; margin: 35px;">
    <img src="CIVIC2.jpg" width="280" height="202" class="card-img-top" alt="Civic">
    <div class="card-body">
        <h5 class="card-title">CIVIC</h5>
        <p class="card-text">Rp 300.000/day,-</p>
        <a href="#" class="btn btn-warning">Detail</a>
    </div>
</div>
<div class="card" style="width: 15rem; float: right; margin: 40px;">
    <img src="inova.jpg" width="280" height="205" class="card-img-top" alt="Inova">
    <div class="card-body">
        <h5 class="card-title">INOVA</h5>
        <p class="card-text">Rp 175.000/day,-</p>
        <a href="#" class="btn btn-warning">Detail</a>
    </div>
</div>
<div class="card" style="width: 18rem; float: right; margin: 40px;">
    <img src="bmw.jpg"  width="280" height="202" class="card-img-top" alt="BMW">
    <div class="card-body">
        <h5 class="card-title">BMW</h5>
        <p class="card-text">Rp 400.000/day,-</p>
        <a href="#" class="btn btn-warning">Detail</a>
    </div>
</div>
<div class="card" style="width: 15rem; float: right; margin: 40px;">
    <img src="crv.png" width="280" height="202" class="card-img-top" alt="CRV">
    <div class="card-body">
        <h5 class="card-title">CRV</h5>
        <p class="card-text">Rp 180.000/day,-</p>
        <a href="#" class="btn btn-warning">Detail</a>
    </div>
</div>
<div class="card" style="width: 14rem; float: right; margin: 40px;">
    <img src="alphard.jpg" width="270" height="200" class="card-img-top" alt="ALPHARD">
    <div class="card-body">
        <h5 class="card-title">ALPHARD</h5>
        <p class="card-text">Rp 450.000/day,-</p>
        <a href="#" class="btn btn-warning">Detail</a>
    </div>
</div>
<div class="card" style="width: 15rem; float: right; margin: 40px;">
    <img src="mercy.webp" width="280" height="202" class="card-img-top" alt="MERCY">
    <div class="card-body">
        <h5 class="card-title">MERCY</h5>
        <p class="card-text">Rp 500.000/day,-</p>
        <a href="#" class="btn btn-warning">Detail</a>
    </div>
</div>
<div class="form" align="center">
<form action="index.php?page=pesanan" method="POST">
<table border="1" >
        <tr>
            <th colspan="2">Form Penyewaan mobil</th>
        </tr>
        <tr>
            <td>Nama Customer</td>
            <td><input type="text"  placeholder="Masukkan Nama" name="namcus"></td>
        </tr>
        <tr>
            <td>Tanggal</td>
            <td><input type="date" name="tanggal"></td>
        </tr>
        
        <tr>
            <td>Merk Mobil</td>
            <td>
            <select class="form-select form-select-lg mb-3" aria-label=".form-select-lg example" name="tipe">
                <option value="pilih">-PILIH-</option>
                <option value="fortuner">Fortuner</option>
                <option value="pajero">Pajero Sport</option>
                <option value="civic">Civic</option>
                <option value="inova">Inova</option>
                <option value="bmw">BMW</option>
                <option value="crv">CRV</option>
                <option value="alphard">Alphard</option>
                <option value="mercy">Mercy</option>
            </select>
            </td>
        </tr>
        <tr>
            <td>Lama Pinjam</td>
            <td><input type="number"  placeholder="Masukkan angka" name="durasi"></td>
        </tr>
        <tr>
            <td align="center" colspan="2"><input type="submit" name="btnok" ><input type="reset" name="btnCancel" value="Cancel"></td>
        </tr>
        </table>
    </form>
</div>
</body>
</html>